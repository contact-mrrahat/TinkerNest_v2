## 9.0.3
* **[LICENSE]** add `Corporate` tier for 250+ employees

## 9.0.2
* **[LICENSE]** clarify build-time license ping in the FlutterBluePlus License

## 9.0.1
* **[Release]** version bump to publish the updated `flutter_blue_plus_platform_interface: ^9.0.0` dependency

## 9.0.0
* **[Fix]** Linux: improve characteristic `instanceId` resolution when multiple services share the same UUID
* **[Improve]** Linux: remove `rxdart` dependency

## 8.2.2
* **[Release]** version bump for the flutter_blue_plus 2.2.2 release

## 8.2.1
* **[LICENSE]** clarifications to the development exemption

## 8.2.0
* **[LICENSE]** new tiers based on company size & development exemption

## 8.1.0
* **[LICENSE]** commercial license is now required for 15 or more employees

## 8.0.1
* Add License symlink

## 8.0.0
* Switch to FBP License

## 3.0.2
* Return unknown state if adaptors list empty (#1190)
* Return empty name if adaptors list empty (#1191)
* Return start scan false if adaptors list empty (#1193)
* Return stop scan false if adaptors list empty (#1194)
* Return turn off false if adaptors list empty (#1195)
* Return turn on false if adaptors list empty (#1196)

## 3.0.1
* Implement on turn on response stream (#1174)

## 3.0.0
* Update platform interface version to 3.0.0

## 2.0.0
* Replace void return types with bool return types

## 1.0.0
* Initial release
